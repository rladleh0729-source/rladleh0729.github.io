import ast
import base64
import hashlib
import json
import math
import os
import re
import secrets
import sys
import threading
from dataclasses import dataclass, asdict
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk

import sentencepiece as spm
import torch
import torch.nn as nn
from torch.nn import functional as F


# =========================================================
# 경로 설정
# =========================================================
def get_app_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


BASE_DIR = get_app_base_dir()
WORK_DIR = BASE_DIR / "work"
CHECKPOINT_DIR = WORK_DIR / "checkpoints"
TOKENIZER_DIR = WORK_DIR / "tokenizer"

SPM_MODEL_PATH = TOKENIZER_DIR / "spm_korean_chat.model"
LATEST_CKPT_PATH = CHECKPOINT_DIR / "latest_checkpoint.pth"
BEST_CKPT_PATH = CHECKPOINT_DIR / "best_checkpoint.pth"

LOCAL_ACCOUNT_ROOT = Path(r"C:\python venv\1_ChosimList")
USERS_DIR = LOCAL_ACCOUNT_ROOT / "users"
SESSION_PATH = LOCAL_ACCOUNT_ROOT / "session.json"
APP_SETTINGS_PATH = BASE_DIR / "chosim_settings.json"

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

WINDOW_TITLE = "ChatChosim_3.0"
MAX_NEW_TOKENS = 120
TEMPERATURE = 0.9
TOP_K = 40

USERS_DIR.mkdir(parents=True, exist_ok=True)


# =========================================================
# 테마
# =========================================================
THEMES = {
    "Midnight": {
        "window_bg": "#0b1020",
        "sidebar_bg": "#0f172a",
        "sidebar_hover": "#1e293b",
        "sidebar_active": "#2563eb",
        "content_bg": "#111827",
        "card_bg": "#ffffff",
        "card_fg": "#182033",
        "muted_fg": "#667085",
        "chat_bg": "#f8fafc",
        "chat_fg": "#111827",
        "user_bg": "#dbeafe",
        "user_fg": "#0f172a",
        "bot_bg": "#f3f4f6",
        "bot_fg": "#111827",
        "calc_bg": "#ede9fe",
        "calc_fg": "#312e81",
        "error_bg": "#fee2e2",
        "error_fg": "#7f1d1d",
        "input_bg": "#ffffff",
        "input_fg": "#111827",
        "status_bg": "#0f172a",
        "status_fg": "#e5e7eb",
        "accent": "#2563eb",
        "accent_fg": "#ffffff",
        "border": "#d6dfeb",
    },
    "Ocean": {
        "window_bg": "#eaf4ff",
        "sidebar_bg": "#16324f",
        "sidebar_hover": "#234765",
        "sidebar_active": "#2f7fd3",
        "content_bg": "#dfefff",
        "card_bg": "#ffffff",
        "card_fg": "#14304b",
        "muted_fg": "#5c748c",
        "chat_bg": "#f8fbff",
        "chat_fg": "#102437",
        "user_bg": "#d6eaff",
        "user_fg": "#123353",
        "bot_bg": "#eef6ff",
        "bot_fg": "#102437",
        "calc_bg": "#e8f0ff",
        "calc_fg": "#1d3b73",
        "error_bg": "#ffe6e6",
        "error_fg": "#8b1e1e",
        "input_bg": "#ffffff",
        "input_fg": "#102437",
        "status_bg": "#16324f",
        "status_fg": "#eef6ff",
        "accent": "#2f7fd3",
        "accent_fg": "#ffffff",
        "border": "#d2e3f2",
    },
    "Graphite": {
        "window_bg": "#1a1f2b",
        "sidebar_bg": "#11151e",
        "sidebar_hover": "#263041",
        "sidebar_active": "#475569",
        "content_bg": "#202738",
        "card_bg": "#f8fafc",
        "card_fg": "#111827",
        "muted_fg": "#5b6472",
        "chat_bg": "#f3f6fa",
        "chat_fg": "#111827",
        "user_bg": "#dce7f5",
        "user_fg": "#0f172a",
        "bot_bg": "#eef2f7",
        "bot_fg": "#111827",
        "calc_bg": "#ede9fe",
        "calc_fg": "#312e81",
        "error_bg": "#fee2e2",
        "error_fg": "#7f1d1d",
        "input_bg": "#ffffff",
        "input_fg": "#111827",
        "status_bg": "#11151e",
        "status_fg": "#e5e7eb",
        "accent": "#475569",
        "accent_fg": "#ffffff",
        "border": "#dbe0e8",
    },
}


# =========================================================
# 앱 설정
# =========================================================
@dataclass
class AppSettings:
    theme_name: str = "Midnight"


def load_app_settings() -> AppSettings:
    if not APP_SETTINGS_PATH.exists():
        return AppSettings()

    try:
        data = json.loads(APP_SETTINGS_PATH.read_text(encoding="utf-8"))
        return AppSettings(theme_name=data.get("theme_name", "Midnight"))
    except Exception:
        return AppSettings()


def save_app_settings(settings: AppSettings):
    APP_SETTINGS_PATH.write_text(
        json.dumps(asdict(settings), ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


# =========================================================
# 로컬 계정 저장소
# =========================================================
def sanitize_username(username: str) -> str:
    username = username.strip()
    if not username:
        raise ValueError("아이디를 입력해야 한다.")
    if not re.fullmatch(r"[A-Za-z0-9_\-]{3,30}", username):
        raise ValueError("아이디는 영문, 숫자, _, - 만 사용할 수 있으며 3~30자여야 한다.")
    return username.lower()


def validate_password(password: str):
    if len(password) < 4:
        raise ValueError("비밀번호는 최소 4자 이상이어야 한다.")


def make_password_hash(password: str, salt: bytes | None = None):
    if salt is None:
        salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 200000)
    return {
        "salt": base64.b64encode(salt).decode("utf-8"),
        "hash": base64.b64encode(dk).decode("utf-8"),
        "iterations": 200000,
        "algorithm": "pbkdf2_sha256",
    }


def verify_password(password: str, record: dict) -> bool:
    salt = base64.b64decode(record["salt"].encode("utf-8"))
    iterations = int(record.get("iterations", 200000))
    expected = base64.b64decode(record["hash"].encode("utf-8"))
    actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return secrets.compare_digest(actual, expected)


def user_file_path(username: str) -> Path:
    return USERS_DIR / f"user_{username}.json"


def user_exists(username: str) -> bool:
    return user_file_path(username).exists()


def create_user(username: str, password: str, nickname: str, status_message: str, email: str):
    username = sanitize_username(username)
    validate_password(password)

    if user_exists(username):
        raise ValueError("이미 존재하는 아이디다.")

    password_record = make_password_hash(password)
    data = {
        "username": username,
        "nickname": nickname.strip() or username,
        "status_message": status_message.strip() or "로컬 계정",
        "email": email.strip(),
        "notes": "",
        "password": password_record,
    }
    user_file_path(username).write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


def load_user(username: str) -> dict:
    username = sanitize_username(username)
    path = user_file_path(username)
    if not path.exists():
        raise ValueError("계정을 찾을 수 없다.")
    return json.loads(path.read_text(encoding="utf-8"))


def save_user(data: dict):
    username = sanitize_username(data["username"])
    user_file_path(username).write_text(
        json.dumps(data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


def login_user(username: str, password: str) -> dict:
    username = sanitize_username(username)
    data = load_user(username)
    if not verify_password(password, data["password"]):
        raise ValueError("비밀번호가 올바르지 않다.")
    return data


def save_session(username: str):
    SESSION_PATH.write_text(
        json.dumps({"username": username}, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )


def clear_session():
    if SESSION_PATH.exists():
        SESSION_PATH.unlink()


def load_session_user() -> dict | None:
    if not SESSION_PATH.exists():
        return None
    try:
        session = json.loads(SESSION_PATH.read_text(encoding="utf-8"))
        username = session.get("username", "")
        if not username:
            return None
        return load_user(username)
    except Exception:
        return None


# =========================================================
# 모델 정의
# =========================================================
@dataclass
class ModelConfig:
    vocab_size: int
    block_size: int
    n_embd: int
    n_head: int
    n_layer: int
    dropout: float


class Head(nn.Module):
    def __init__(self, head_size: int, config: ModelConfig):
        super().__init__()
        self.key = nn.Linear(config.n_embd, head_size, bias=False)
        self.query = nn.Linear(config.n_embd, head_size, bias=False)
        self.value = nn.Linear(config.n_embd, head_size, bias=False)
        self.dropout = nn.Dropout(config.dropout)
        self.register_buffer("tril", torch.tril(torch.ones(config.block_size, config.block_size)))

    def forward(self, x):
        _, t, _ = x.shape
        k = self.key(x)
        q = self.query(x)
        wei = q @ k.transpose(-2, -1) * (k.shape[-1] ** -0.5)
        wei = wei.masked_fill(self.tril[:t, :t] == 0, float("-inf"))
        wei = F.softmax(wei, dim=-1)
        wei = self.dropout(wei)
        v = self.value(x)
        return wei @ v


class MultiHeadAttention(nn.Module):
    def __init__(self, num_heads: int, head_size: int, config: ModelConfig):
        super().__init__()
        self.heads = nn.ModuleList([Head(head_size, config) for _ in range(num_heads)])
        self.proj = nn.Linear(config.n_embd, config.n_embd)
        self.dropout = nn.Dropout(config.dropout)

    def forward(self, x):
        out = torch.cat([h(x) for h in self.heads], dim=-1)
        out = self.dropout(self.proj(out))
        return out


class FeedForward(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(config.n_embd, 4 * config.n_embd),
            nn.GELU(),
            nn.Linear(4 * config.n_embd, config.n_embd),
            nn.Dropout(config.dropout),
        )

    def forward(self, x):
        return self.net(x)


class Block(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        head_size = config.n_embd // config.n_head
        self.sa = MultiHeadAttention(config.n_head, head_size, config)
        self.ffwd = FeedForward(config)
        self.ln1 = nn.LayerNorm(config.n_embd)
        self.ln2 = nn.LayerNorm(config.n_embd)

    def forward(self, x):
        x = x + self.sa(self.ln1(x))
        x = x + self.ffwd(self.ln2(x))
        return x


class ChosimLanguageModel(nn.Module):
    def __init__(self, config: ModelConfig):
        super().__init__()
        self.config = config
        self.token_embedding_table = nn.Embedding(config.vocab_size, config.n_embd)
        self.position_embedding_table = nn.Embedding(config.block_size, config.n_embd)
        self.blocks = nn.Sequential(*[Block(config) for _ in range(config.n_layer)])
        self.ln_f = nn.LayerNorm(config.n_embd)
        self.lm_head = nn.Linear(config.n_embd, config.vocab_size)
        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, (nn.Linear, nn.Embedding)):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if isinstance(module, nn.Linear) and module.bias is not None:
                torch.nn.init.zeros_(module.bias)

    def forward(self, idx, targets=None):
        b, t = idx.shape
        tok_emb = self.token_embedding_table(idx)
        pos_emb = self.position_embedding_table(torch.arange(t, device=idx.device))
        x = tok_emb + pos_emb
        x = self.blocks(x)
        x = self.ln_f(x)
        logits = self.lm_head(x)

        loss = None
        if targets is not None:
            b2, t2, c = logits.shape
            logits = logits.view(b2 * t2, c)
            targets = targets.view(b2 * t2)
            loss = F.cross_entropy(logits, targets)

        return logits, loss


# =========================================================
# 체크포인트 / 토크나이저
# =========================================================
def load_sp_processor() -> spm.SentencePieceProcessor:
    if not SPM_MODEL_PATH.exists():
        raise FileNotFoundError(f"토크나이저 파일이 없다.\n{SPM_MODEL_PATH}")
    sp = spm.SentencePieceProcessor()
    if not sp.load(str(SPM_MODEL_PATH)):
        raise RuntimeError("SentencePiece 로드 실패")
    return sp


def choose_checkpoint_path() -> Path:
    if BEST_CKPT_PATH.exists():
        return BEST_CKPT_PATH
    if LATEST_CKPT_PATH.exists():
        return LATEST_CKPT_PATH
    iter_ckpts = sorted(CHECKPOINT_DIR.glob("iter_*.pth"))
    if iter_ckpts:
        return iter_ckpts[-1]
    raise FileNotFoundError(f"체크포인트를 찾을 수 없다.\n{CHECKPOINT_DIR}")


def load_model_from_checkpoint(ckpt_path: Path):
    ckpt = torch.load(ckpt_path, map_location=DEVICE)
    config_dict = ckpt["config"]
    config = ModelConfig(
        vocab_size=int(config_dict["vocab_size"]),
        block_size=int(config_dict["block_size"]),
        n_embd=int(config_dict["n_embd"]),
        n_head=int(config_dict["n_head"]),
        n_layer=int(config_dict["n_layer"]),
        dropout=float(config_dict["dropout"]),
    )
    model = ChosimLanguageModel(config).to(DEVICE)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()
    return model, ckpt


@torch.no_grad()
def generate_text(model, sp, prompt, max_new_tokens=120, temperature=1.0, top_k=40):
    ids = sp.encode(prompt, out_type=int)
    if not ids:
        bos_id = sp.bos_id()
        ids = [bos_id] if bos_id >= 0 else [1]

    idx = torch.tensor(ids, dtype=torch.long, device=DEVICE).unsqueeze(0)
    eos_id = sp.eos_id()
    block_size = model.config.block_size
    temp = temperature if temperature > 0 else 1.0

    for _ in range(max_new_tokens):
        idx_cond = idx[:, -block_size:]
        logits, _ = model(idx_cond)
        logits = logits[:, -1, :]
        logits = logits / temp

        if top_k is not None and top_k > 0:
            values, _ = torch.topk(logits, min(top_k, logits.size(-1)))
            logits[logits < values[:, [-1]]] = float("-inf")

        probs = F.softmax(logits, dim=-1)
        idx_next = torch.multinomial(probs, num_samples=1)
        idx = torch.cat((idx, idx_next), dim=1)

        if eos_id >= 0 and int(idx_next.item()) == eos_id:
            break

    return sp.decode(idx[0].tolist())


# =========================================================
# 수학 계산
# =========================================================
_ALLOWED_FUNCTIONS = {
    "sqrt": math.sqrt,
    "log": math.log10,
    "ln": math.log,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "abs": abs,
    "round": round,
    "floor": math.floor,
    "ceil": math.ceil,
    "exp": math.exp,
    "fact": math.factorial,
    "factorial": math.factorial,
}
_ALLOWED_CONSTANTS = {"pi": math.pi, "e": math.e}
_MATH_ALLOWED_CHARS_PATTERN = re.compile(r"^[0-9a-zA-Z_+\-*/().,^%\s=!<>|&]+$")


def preprocess_math_expression(expr: str) -> str:
    text = expr.strip()
    replacements = {
        "×": "*",
        "÷": "/",
        "−": "-",
        "–": "-",
        "—": "-",
        "√": "sqrt",
        "^": "**",
        "π": "pi",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"(\d+(?:\.\d+)?)\s*%", r"(\1/100)", text)
    return text


def looks_like_math_expression(text: str) -> bool:
    expr = text.strip()
    if not expr:
        return False

    lowered = expr.lower()
    blocked_words = ["안녕", "뭐", "왜", "어때", "이름", "설명", "말해", "대화", "hello", "hi"]
    if any(word in lowered for word in blocked_words):
        return False
    if re.search(r"[가-힣]", expr):
        return False
    if not _MATH_ALLOWED_CHARS_PATTERN.fullmatch(expr.replace("π", "pi").replace("√", "sqrt")):
        return False

    math_keywords = [
        "sqrt", "log", "ln", "sin", "cos", "tan",
        "asin", "acos", "atan", "abs", "round",
        "floor", "ceil", "exp", "fact", "factorial", "pi", "e"
    ]
    operator_chars = set("+-*/^%()=<>!&|,")
    has_digit = any(ch.isdigit() for ch in expr)
    has_operator = any(ch in operator_chars for ch in expr)
    has_keyword = any(keyword in lowered for keyword in math_keywords)
    return has_digit or has_operator or has_keyword


def safe_eval_math(expr: str):
    expr = preprocess_math_expression(expr)

    if expr.endswith("=") and "==" not in expr and ">=" not in expr and "<=" not in expr and "!=" not in expr:
        expr = expr[:-1].strip()

    tree = ast.parse(expr, mode="eval")

    def eval_node(node):
        if isinstance(node, ast.Expression):
            return eval_node(node.body)

        if isinstance(node, ast.Constant):
            if isinstance(node.value, (int, float, bool)):
                return node.value
            raise ValueError("허용되지 않는 상수다.")

        if isinstance(node, ast.Num):
            return node.n

        if isinstance(node, ast.Name):
            if node.id in _ALLOWED_CONSTANTS:
                return _ALLOWED_CONSTANTS[node.id]
            raise ValueError(f"허용되지 않는 이름: {node.id}")

        if isinstance(node, ast.BinOp):
            left = eval_node(node.left)
            right = eval_node(node.right)
            if isinstance(node.op, ast.Add):
                return left + right
            if isinstance(node.op, ast.Sub):
                return left - right
            if isinstance(node.op, ast.Mult):
                return left * right
            if isinstance(node.op, ast.Div):
                return left / right
            if isinstance(node.op, ast.FloorDiv):
                return left // right
            if isinstance(node.op, ast.Mod):
                return left % right
            if isinstance(node.op, ast.Pow):
                return left ** right
            raise ValueError("허용되지 않는 연산자다.")

        if isinstance(node, ast.UnaryOp):
            operand = eval_node(node.operand)
            if isinstance(node.op, ast.UAdd):
                return +operand
            if isinstance(node.op, ast.USub):
                return -operand
            if isinstance(node.op, ast.Not):
                return not operand
            raise ValueError("허용되지 않는 단항 연산이다.")

        if isinstance(node, ast.Call):
            if not isinstance(node.func, ast.Name):
                raise ValueError("허용되지 않는 함수 호출이다.")
            func_name = node.func.id
            if func_name not in _ALLOWED_FUNCTIONS:
                raise ValueError(f"허용되지 않는 함수: {func_name}")
            func = _ALLOWED_FUNCTIONS[func_name]
            args = [eval_node(arg) for arg in node.args]

            if func_name == "log":
                if len(args) == 1:
                    if args[0] <= 0:
                        raise ValueError("log(x)는 x > 0 이어야 한다.")
                    return math.log10(args[0])
                if len(args) == 2:
                    if args[0] <= 0 or args[1] <= 0 or args[1] == 1:
                        raise ValueError("log(x, b)는 x > 0, b > 0, b != 1 이어야 한다.")
                    return math.log(args[0], args[1])
                raise ValueError("log는 인자를 1개 또는 2개 받는다.")

            if func_name == "ln":
                if len(args) != 1:
                    raise ValueError("ln은 인자를 1개 받는다.")
                if args[0] <= 0:
                    raise ValueError("ln(x)는 x > 0 이어야 한다.")
                return math.log(args[0])

            if func_name in ("fact", "factorial"):
                if len(args) != 1:
                    raise ValueError("factorial은 인자를 1개 받는다.")
                if not float(args[0]).is_integer() or args[0] < 0:
                    raise ValueError("factorial은 0 이상의 정수만 가능하다.")
                return math.factorial(int(args[0]))

            return func(*args)

        if isinstance(node, ast.Compare):
            left = eval_node(node.left)
            result = True
            current = left
            for op, comparator in zip(node.ops, node.comparators):
                right = eval_node(comparator)
                if isinstance(op, ast.Eq):
                    ok = current == right
                elif isinstance(op, ast.NotEq):
                    ok = current != right
                elif isinstance(op, ast.Lt):
                    ok = current < right
                elif isinstance(op, ast.LtE):
                    ok = current <= right
                elif isinstance(op, ast.Gt):
                    ok = current > right
                elif isinstance(op, ast.GtE):
                    ok = current >= right
                else:
                    raise ValueError("허용되지 않는 비교 연산자다.")
                result = result and ok
                current = right
            return result

        if isinstance(node, ast.BoolOp):
            values = [eval_node(v) for v in node.values]
            if isinstance(node.op, ast.And):
                return all(values)
            if isinstance(node.op, ast.Or):
                return any(values)
            raise ValueError("허용되지 않는 논리 연산이다.")

        raise ValueError("허용되지 않는 수식이다.")

    result = eval_node(tree)

    if isinstance(result, float):
        if math.isinf(result) or math.isnan(result):
            raise ValueError("계산 결과가 유효하지 않다.")
        result = round(result, 12)
        if result.is_integer():
            result = int(result)

    return result


# =========================================================
# 메인 앱
# =========================================================
class ChatChosimApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title(WINDOW_TITLE)
        self.root.geometry("1260x820")
        self.root.minsize(1080, 700)

        self.settings = load_app_settings()
        self.theme_name = self.settings.theme_name if self.settings.theme_name in THEMES else "Midnight"
        self.theme = THEMES[self.theme_name]

        self.model = None
        self.sp = None
        self.ckpt_info = None
        self.is_loading = False
        self.is_generating = False

        self.current_user = load_session_user()

        self.status_var = tk.StringVar(value="시작 중...")
        self.account_status_var = tk.StringVar(value="")
        self.sidebar_selected = "chat"

        self._setup_theme()
        self._build_ui()
        self._apply_theme()
        self._refresh_account_ui()
        self._load_model_async()

    # ---------------- Theme ----------------
    def _setup_theme(self):
        style = ttk.Style()
        try:
            if "vista" in style.theme_names():
                style.theme_use("vista")
            elif "clam" in style.theme_names():
                style.theme_use("clam")
        except Exception:
            pass

    def _apply_theme(self):
        t = self.theme
        self.root.configure(bg=t["window_bg"])

        self.sidebar.configure(bg=t["sidebar_bg"])
        self.logo_frame.configure(bg=t["sidebar_bg"])
        self.logo_title.configure(bg=t["sidebar_bg"], fg="#ffffff")
        self.logo_sub.configure(bg=t["sidebar_bg"], fg="#cbd5e1")
        self.account_chip.configure(bg=t["sidebar_bg"], fg="#cbd5e1")

        for key, btn in self.nav_buttons.items():
            if key == self.sidebar_selected:
                btn.configure(bg=t["sidebar_active"], fg=t["accent_fg"], activebackground=t["sidebar_active"], activeforeground=t["accent_fg"])
            else:
                btn.configure(bg=t["sidebar_bg"], fg="#e5e7eb", activebackground=t["sidebar_hover"], activeforeground="#ffffff")

        self.main_area.configure(bg=t["content_bg"])
        self.page_header.configure(bg=t["content_bg"])
        self.page_title.configure(bg=t["content_bg"], fg="#ffffff")
        self.page_desc.configure(bg=t["content_bg"], fg="#d1d5db")

        self.chat_page.configure(bg=t["content_bg"])
        self.settings_page.configure(bg=t["content_bg"])

        for frame in [self.chat_top_card, self.chat_main_card, self.chat_input_card,
                      self.settings_account_card, self.settings_theme_card]:
            frame.configure(bg=t["card_bg"], highlightbackground=t["border"], highlightthickness=1)

        for lbl in [self.chat_top_title, self.chat_top_desc, self.settings_account_title, self.settings_account_desc,
                    self.settings_theme_title, self.settings_theme_desc]:
            lbl.configure(bg=t["card_bg"], fg=t["card_fg"])

        for lbl in [self.model_info_label, self.account_info_label]:
            lbl.configure(bg=t["card_bg"], fg=t["muted_fg"])

        self.chat_area.configure(
            bg=t["chat_bg"],
            fg=t["chat_fg"],
            insertbackground=t["chat_fg"]
        )
        self.chat_area.tag_config("system", foreground=t["muted_fg"], background=t["chat_bg"])
        self.chat_area.tag_config("user", foreground=t["user_fg"], background=t["user_bg"])
        self.chat_area.tag_config("bot", foreground=t["bot_fg"], background=t["bot_bg"])
        self.chat_area.tag_config("calc", foreground=t["calc_fg"], background=t["calc_bg"])
        self.chat_area.tag_config("error", foreground=t["error_fg"], background=t["error_bg"])

        self.entry.configure(bg=t["input_bg"], fg=t["input_fg"], insertbackground=t["input_fg"])

        for widget in [self.login_user_entry, self.login_pass_entry,
                       self.register_user_entry, self.register_pass_entry,
                       self.register_nick_entry, self.register_email_entry,
                       self.profile_nick_entry, self.profile_status_entry,
                       self.profile_email_entry]:
            widget.configure(bg=t["input_bg"], fg=t["input_fg"], insertbackground=t["input_fg"])

        self.profile_notes_text.configure(bg=t["input_bg"], fg=t["input_fg"], insertbackground=t["input_fg"])

        self.status_bar.configure(bg=t["status_bg"])
        self.status_label.configure(bg=t["status_bg"], fg=t["status_fg"])

        self.send_button.configure(bg=t["accent"], fg=t["accent_fg"], activebackground=t["accent"], activeforeground=t["accent_fg"])
        self.reload_button.configure(bg=t["accent"], fg=t["accent_fg"], activebackground=t["accent"], activeforeground=t["accent_fg"])
        self.clear_button.configure(bg="#e5e7eb", fg="#111827", activebackground="#d1d5db", activeforeground="#111827")
        self.login_button.configure(bg=t["accent"], fg=t["accent_fg"], activebackground=t["accent"], activeforeground=t["accent_fg"])
        self.register_button.configure(bg=t["accent"], fg=t["accent_fg"], activebackground=t["accent"], activeforeground=t["accent_fg"])
        self.logout_button.configure(bg="#ef4444", fg="#ffffff", activebackground="#dc2626", activeforeground="#ffffff")
        self.profile_save_button.configure(bg=t["accent"], fg=t["accent_fg"], activebackground=t["accent"], activeforeground=t["accent_fg"])
        self.apply_theme_button.configure(bg=t["accent"], fg=t["accent_fg"], activebackground=t["accent"], activeforeground=t["accent_fg"])

        self.theme_value_label.configure(bg=t["card_bg"], fg=t["muted_fg"])
        self.account_status_label.configure(bg=t["card_bg"], fg=t["muted_fg"])

    # ---------------- UI ----------------
    def _build_ui(self):
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(1, weight=1)

        # Sidebar
        self.sidebar = tk.Frame(self.root, width=240)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)

        self.logo_frame = tk.Frame(self.sidebar)
        self.logo_frame.pack(fill="x", padx=18, pady=(22, 18))

        self.logo_title = tk.Label(self.logo_frame, text="ChatChosim_3.0", font=("맑은 고딕", 18, "bold"))
        self.logo_title.pack(anchor="w")

        self.logo_sub = tk.Label(
            self.logo_frame,
            text="Desktop AI Workspace",
            font=("맑은 고딕", 9)
        )
        self.logo_sub.pack(anchor="w", pady=(4, 8))

        self.account_chip = tk.Label(self.logo_frame, text="", font=("맑은 고딕", 9, "bold"))
        self.account_chip.pack(anchor="w")

        self.nav_buttons = {}
        self.nav_buttons["chat"] = self._make_sidebar_button("채팅", lambda: self._show_page("chat"))
        self.nav_buttons["settings"] = self._make_sidebar_button("설정", lambda: self._show_page("settings"))

        # Main
        self.main_area = tk.Frame(self.root)
        self.main_area.grid(row=0, column=1, sticky="nsew")
        self.main_area.grid_rowconfigure(1, weight=1)
        self.main_area.grid_columnconfigure(0, weight=1)

        self.page_header = tk.Frame(self.main_area)
        self.page_header.grid(row=0, column=0, sticky="ew", padx=24, pady=(22, 12))

        self.page_title = tk.Label(self.page_header, text="채팅", font=("맑은 고딕", 22, "bold"))
        self.page_title.pack(anchor="w")

        self.page_desc = tk.Label(
            self.page_header,
            text="현재 체크포인트 기반 대화와 계산을 한 화면에서 처리한다.",
            font=("맑은 고딕", 10)
        )
        self.page_desc.pack(anchor="w", pady=(6, 0))

        self.page_container = tk.Frame(self.main_area)
        self.page_container.grid(row=1, column=0, sticky="nsew", padx=24, pady=(0, 0))
        self.page_container.grid_rowconfigure(0, weight=1)
        self.page_container.grid_columnconfigure(0, weight=1)

        # Chat Page
        self.chat_page = tk.Frame(self.page_container)
        self.chat_page.grid(row=0, column=0, sticky="nsew")
        self.chat_page.grid_rowconfigure(1, weight=1)
        self.chat_page.grid_columnconfigure(0, weight=1)

        self.chat_top_card = tk.Frame(self.chat_page, padx=18, pady=16)
        self.chat_top_card.grid(row=0, column=0, sticky="ew", pady=(0, 14))

        self.chat_top_title = tk.Label(self.chat_top_card, text="현재 세션", font=("맑은 고딕", 12, "bold"))
        self.chat_top_title.pack(anchor="w")

        self.chat_top_desc = tk.Label(self.chat_top_card, text="모델, 계정, 실행 환경 정보를 여기서 확인한다.", font=("맑은 고딕", 10))
        self.chat_top_desc.pack(anchor="w", pady=(6, 10))

        self.model_info_label = tk.Label(self.chat_top_card, text="모델: 로딩 중...", font=("맑은 고딕", 9))
        self.model_info_label.pack(anchor="w")

        self.account_info_label = tk.Label(self.chat_top_card, text="계정: 로그인되지 않음", font=("맑은 고딕", 9))
        self.account_info_label.pack(anchor="w", pady=(4, 0))

        self.chat_main_card = tk.Frame(self.chat_page, padx=18, pady=18)
        self.chat_main_card.grid(row=1, column=0, sticky="nsew", pady=(0, 14))
        self.chat_main_card.grid_rowconfigure(0, weight=1)
        self.chat_main_card.grid_columnconfigure(0, weight=1)

        self.chat_area = scrolledtext.ScrolledText(
            self.chat_main_card,
            wrap=tk.WORD,
            font=("맑은 고딕", 11),
            relief="flat",
            borderwidth=0,
            padx=18,
            pady=16,
            spacing1=4,
            spacing2=2,
            spacing3=7,
            state="disabled"
        )
        self.chat_area.grid(row=0, column=0, sticky="nsew")

        self.chat_main_card.grid_rowconfigure(0, weight=1)
        self.chat_main_card.grid_columnconfigure(0, weight=1)

        self.chat_input_card = tk.Frame(self.chat_page, padx=18, pady=14)
        self.chat_input_card.grid(row=2, column=0, sticky="ew")
        self.chat_input_card.grid_columnconfigure(0, weight=1)

        self.entry = tk.Entry(self.chat_input_card, font=("맑은 고딕", 12), relief="flat", bd=0)
        self.entry.grid(row=0, column=0, sticky="ew", padx=(0, 10), ipady=12)
        self.entry.bind("<Return>", self._on_enter)
        self.entry.bind("<KP_Enter>", self._on_enter)

        self.send_button = tk.Button(self.chat_input_card, text="보내기", font=("맑은 고딕", 10, "bold"), relief="flat", bd=0, command=self.send_message)
        self.send_button.grid(row=0, column=1, padx=(0, 8), ipadx=18, ipady=10)

        self.reload_button = tk.Button(self.chat_input_card, text="다시 불러오기", font=("맑은 고딕", 10), relief="flat", bd=0, command=self._reload_model)
        self.reload_button.grid(row=0, column=2, padx=(0, 8), ipadx=12, ipady=10)

        self.clear_button = tk.Button(self.chat_input_card, text="대화 지우기", font=("맑은 고딕", 10), relief="flat", bd=0, command=self._clear_chat)
        self.clear_button.grid(row=0, column=3, ipadx=12, ipady=10)

        # Settings Page
        self.settings_page = tk.Frame(self.page_container)
        self.settings_page.grid(row=0, column=0, sticky="nsew")
        self.settings_page.grid_columnconfigure(0, weight=1)

        self.settings_account_card = tk.Frame(self.settings_page, padx=18, pady=18)
        self.settings_account_card.grid(row=0, column=0, sticky="ew", pady=(0, 14))

        self.settings_account_title = tk.Label(self.settings_account_card, text="계정", font=("맑은 고딕", 12, "bold"))
        self.settings_account_title.grid(row=0, column=0, sticky="w")

        self.settings_account_desc = tk.Label(
            self.settings_account_card,
            text=r'로컬 계정 저장 위치: C:\python venv\1_ChosimList',
            font=("맑은 고딕", 10)
        )
        self.settings_account_desc.grid(row=1, column=0, sticky="w", pady=(6, 10), columnspan=4)

        self.account_status_label = tk.Label(self.settings_account_card, textvariable=self.account_status_var, font=("맑은 고딕", 9))
        self.account_status_label.grid(row=2, column=0, sticky="w", pady=(0, 14), columnspan=4)

        # Login
        tk.Label(self.settings_account_card, text="로그인", font=("맑은 고딕", 11, "bold")).grid(row=3, column=0, sticky="w", pady=(0, 8))
        tk.Label(self.settings_account_card, text="아이디", font=("맑은 고딕", 10)).grid(row=4, column=0, sticky="w")
        tk.Label(self.settings_account_card, text="비밀번호", font=("맑은 고딕", 10)).grid(row=4, column=1, sticky="w")

        self.login_user_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.login_user_entry.grid(row=5, column=0, sticky="ew", padx=(0, 8), ipady=8)

        self.login_pass_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0, show="*")
        self.login_pass_entry.grid(row=5, column=1, sticky="ew", padx=(0, 8), ipady=8)

        self.login_button = tk.Button(self.settings_account_card, text="로그인", font=("맑은 고딕", 10, "bold"), relief="flat", bd=0, command=self._login)
        self.login_button.grid(row=5, column=2, sticky="ew", ipadx=12, ipady=8)

        self.logout_button = tk.Button(self.settings_account_card, text="로그아웃", font=("맑은 고딕", 10, "bold"), relief="flat", bd=0, command=self._logout)
        self.logout_button.grid(row=5, column=3, sticky="ew", ipadx=12, ipady=8)

        # Register
        tk.Label(self.settings_account_card, text="회원가입", font=("맑은 고딕", 11, "bold")).grid(row=6, column=0, sticky="w", pady=(20, 8))
        tk.Label(self.settings_account_card, text="아이디", font=("맑은 고딕", 10)).grid(row=7, column=0, sticky="w")
        tk.Label(self.settings_account_card, text="비밀번호", font=("맑은 고딕", 10)).grid(row=7, column=1, sticky="w")
        tk.Label(self.settings_account_card, text="닉네임", font=("맑은 고딕", 10)).grid(row=7, column=2, sticky="w")
        tk.Label(self.settings_account_card, text="이메일", font=("맑은 고딕", 10)).grid(row=7, column=3, sticky="w")

        self.register_user_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.register_user_entry.grid(row=8, column=0, sticky="ew", padx=(0, 8), ipady=8)

        self.register_pass_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0, show="*")
        self.register_pass_entry.grid(row=8, column=1, sticky="ew", padx=(0, 8), ipady=8)

        self.register_nick_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.register_nick_entry.grid(row=8, column=2, sticky="ew", padx=(0, 8), ipady=8)

        self.register_email_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.register_email_entry.grid(row=8, column=3, sticky="ew", padx=(0, 8), ipady=8)

        self.register_button = tk.Button(self.settings_account_card, text="회원가입", font=("맑은 고딕", 10, "bold"), relief="flat", bd=0, command=self._register)
        self.register_button.grid(row=9, column=0, sticky="w", pady=(10, 0), ipadx=14, ipady=8)

        # Profile
        tk.Label(self.settings_account_card, text="프로필", font=("맑은 고딕", 11, "bold")).grid(row=10, column=0, sticky="w", pady=(22, 8))

        tk.Label(self.settings_account_card, text="닉네임", font=("맑은 고딕", 10)).grid(row=11, column=0, sticky="w")
        tk.Label(self.settings_account_card, text="상태메시지", font=("맑은 고딕", 10)).grid(row=11, column=1, sticky="w")
        tk.Label(self.settings_account_card, text="이메일", font=("맑은 고딕", 10)).grid(row=11, column=2, sticky="w")

        self.profile_nick_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.profile_nick_entry.grid(row=12, column=0, sticky="ew", padx=(0, 8), ipady=8)

        self.profile_status_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.profile_status_entry.grid(row=12, column=1, sticky="ew", padx=(0, 8), ipady=8)

        self.profile_email_entry = tk.Entry(self.settings_account_card, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.profile_email_entry.grid(row=12, column=2, sticky="ew", padx=(0, 8), ipady=8)

        self.profile_save_button = tk.Button(self.settings_account_card, text="프로필 저장", font=("맑은 고딕", 10, "bold"), relief="flat", bd=0, command=self._save_profile)
        self.profile_save_button.grid(row=12, column=3, sticky="ew", ipadx=12, ipady=8)

        tk.Label(self.settings_account_card, text="메모", font=("맑은 고딕", 10)).grid(row=13, column=0, sticky="w", pady=(12, 6))
        self.profile_notes_text = tk.Text(self.settings_account_card, height=4, font=("맑은 고딕", 10), relief="flat", bd=0)
        self.profile_notes_text.grid(row=14, column=0, columnspan=4, sticky="ew")

        for i in range(4):
            self.settings_account_card.grid_columnconfigure(i, weight=1)

        # Theme card
        self.settings_theme_card = tk.Frame(self.settings_page, padx=18, pady=18)
        self.settings_theme_card.grid(row=1, column=0, sticky="ew")

        self.settings_theme_title = tk.Label(self.settings_theme_card, text="배경 색 / 테마", font=("맑은 고딕", 12, "bold"))
        self.settings_theme_title.grid(row=0, column=0, sticky="w")

        self.settings_theme_desc = tk.Label(self.settings_theme_card, text="앱 전체 배경과 패널 색을 바꾼다.", font=("맑은 고딕", 10))
        self.settings_theme_desc.grid(row=1, column=0, sticky="w", pady=(6, 12), columnspan=3)

        self.theme_var = tk.StringVar(value=self.theme_name)
        self.theme_combo = ttk.Combobox(self.settings_theme_card, textvariable=self.theme_var, values=list(THEMES.keys()), state="readonly", width=18)
        self.theme_combo.grid(row=2, column=0, sticky="w", padx=(0, 10))

        self.apply_theme_button = tk.Button(self.settings_theme_card, text="테마 적용", font=("맑은 고딕", 10, "bold"), relief="flat", bd=0, command=self._change_theme)
        self.apply_theme_button.grid(row=2, column=1, sticky="w", ipadx=12, ipady=8)

        self.theme_value_label = tk.Label(self.settings_theme_card, text=f"현재 테마: {self.theme_name}", font=("맑은 고딕", 9))
        self.theme_value_label.grid(row=3, column=0, sticky="w", pady=(10, 0), columnspan=3)

        # Status
        self.status_bar = tk.Frame(self.main_area)
        self.status_bar.grid(row=2, column=0, sticky="ew")
        self.status_label = tk.Label(self.status_bar, textvariable=self.status_var, font=("맑은 고딕", 9), anchor="w")
        self.status_label.pack(fill="x", padx=18, pady=10)

        self._show_page("chat")
        self._append_message("system", "ChatChosim_3.0 실행 시작")

    def _make_sidebar_button(self, text: str, command):
        btn = tk.Button(
            self.sidebar,
            text=text,
            font=("맑은 고딕", 11, "bold"),
            anchor="w",
            relief="flat",
            bd=0,
            padx=18,
            pady=14,
            command=command
        )
        btn.pack(fill="x", padx=14, pady=4)
        return btn

    def _show_page(self, page_name: str):
        self.sidebar_selected = page_name
        if page_name == "chat":
            self.chat_page.tkraise()
            self.page_title.configure(text="채팅")
            self.page_desc.configure(text="현재 체크포인트 기반 대화와 계산을 한 화면에서 처리한다.")
        else:
            self.settings_page.tkraise()
            self.page_title.configure(text="설정")
            self.page_desc.configure(text="로컬 계정, 비밀번호 저장, 프로필, 테마를 관리한다.")
        self._apply_theme()

    # ---------------- Account ----------------
    def _refresh_account_ui(self):
        if self.current_user:
            username = self.current_user["username"]
            nickname = self.current_user.get("nickname", username)
            status_msg = self.current_user.get("status_message", "")
            self.account_chip.configure(text=f"{nickname} · 로그인됨")
            self.account_info_label.configure(text=f"계정: {username} / {nickname} / {status_msg}")
            self.account_status_var.set(f"현재 로그인: {username}")
            self.profile_nick_entry.delete(0, tk.END)
            self.profile_nick_entry.insert(0, self.current_user.get("nickname", ""))
            self.profile_status_entry.delete(0, tk.END)
            self.profile_status_entry.insert(0, self.current_user.get("status_message", ""))
            self.profile_email_entry.delete(0, tk.END)
            self.profile_email_entry.insert(0, self.current_user.get("email", ""))
            self.profile_notes_text.delete("1.0", tk.END)
            self.profile_notes_text.insert("1.0", self.current_user.get("notes", ""))
        else:
            self.account_chip.configure(text="로그인 없음")
            self.account_info_label.configure(text="계정: 로그인되지 않음")
            self.account_status_var.set("현재 로그인 없음")
            self.profile_nick_entry.delete(0, tk.END)
            self.profile_status_entry.delete(0, tk.END)
            self.profile_email_entry.delete(0, tk.END)
            self.profile_notes_text.delete("1.0", tk.END)

    def _login(self):
        username = self.login_user_entry.get().strip()
        password = self.login_pass_entry.get()
        try:
            self.current_user = login_user(username, password)
            save_session(self.current_user["username"])
            self._refresh_account_ui()
            self._append_message("system", f"{self.current_user['username']} 계정으로 로그인 완료")
            self._set_status("로그인 완료")
        except Exception as e:
            messagebox.showerror("로그인 실패", str(e))

    def _register(self):
        username = self.register_user_entry.get().strip()
        password = self.register_pass_entry.get()
        nickname = self.register_nick_entry.get().strip()
        email = self.register_email_entry.get().strip()
        try:
            create_user(username, password, nickname, "로컬 계정", email)
            messagebox.showinfo("회원가입 완료", "계정이 생성되었다.")
            self._set_status("회원가입 완료")
        except Exception as e:
            messagebox.showerror("회원가입 실패", str(e))

    def _logout(self):
        self.current_user = None
        clear_session()
        self._refresh_account_ui()
        self._append_message("system", "로그아웃 완료")
        self._set_status("로그아웃 완료")

    def _save_profile(self):
        if not self.current_user:
            messagebox.showwarning("저장 불가", "먼저 로그인해야 한다.")
            return

        self.current_user["nickname"] = self.profile_nick_entry.get().strip() or self.current_user["username"]
        self.current_user["status_message"] = self.profile_status_entry.get().strip()
        self.current_user["email"] = self.profile_email_entry.get().strip()
        self.current_user["notes"] = self.profile_notes_text.get("1.0", tk.END).strip()
        save_user(self.current_user)
        self._refresh_account_ui()
        self._set_status("프로필 저장 완료")
        self._append_message("system", "프로필 저장 완료")

    # ---------------- Theme ----------------
    def _change_theme(self):
        selected = self.theme_var.get()
        if selected not in THEMES:
            return
        self.theme_name = selected
        self.theme = THEMES[selected]
        self.settings.theme_name = selected
        save_app_settings(self.settings)
        self.theme_value_label.configure(text=f"현재 테마: {selected}")
        self._apply_theme()
        self._set_status(f"테마 적용: {selected}")

    # ---------------- Chat ----------------
    def _append_message(self, role: str, text: str):
        self.chat_area.configure(state="normal")

        if role == "user":
            rendered = f"나\n{text}\n\n"
            tag = "user"
        elif role == "bot":
            rendered = f"ChatChosim_3.0\n{text}\n\n"
            tag = "bot"
        elif role == "calc":
            rendered = f"계산\n{text}\n\n"
            tag = "calc"
        elif role == "error":
            rendered = f"오류\n{text}\n\n"
            tag = "error"
        else:
            rendered = f"• {text}\n\n"
            tag = "system"

        self.chat_area.insert(tk.END, rendered, tag)
        self.chat_area.configure(state="disabled")
        self.chat_area.see(tk.END)

    def _clear_chat(self):
        self.chat_area.configure(state="normal")
        self.chat_area.delete("1.0", tk.END)
        self.chat_area.configure(state="disabled")
        self._append_message("system", "대화 기록을 지웠다.")

    def _set_status(self, text: str):
        self.status_var.set(text)

    def _set_ui_busy(self, busy: bool):
        state = "disabled" if busy else "normal"
        self.send_button.configure(state=state)
        self.reload_button.configure(state=state)
        self.clear_button.configure(state=state)
        self.entry.configure(state=state)

    def _on_enter(self, event):
        self.send_message()

    def _reload_model(self):
        if self.is_loading or self.is_generating:
            return
        self._append_message("system", "모델 다시 불러오는 중...")
        self._load_model_async()

    def _load_model_async(self):
        self.is_loading = True
        self._set_ui_busy(True)
        self._set_status("모델 로딩 중...")
        thread = threading.Thread(target=self._load_model_worker, daemon=True)
        thread.start()

    def _load_model_worker(self):
        try:
            sp = load_sp_processor()
            ckpt_path = choose_checkpoint_path()
            model, ckpt = load_model_from_checkpoint(ckpt_path)
            info = {
                "ckpt_path": str(ckpt_path),
                "iter_num": ckpt.get("iter_num", "알 수 없음"),
                "best_val_loss": ckpt.get("best_val_loss", "알 수 없음"),
            }
            self.root.after(0, lambda: self._load_model_success(model, sp, info))
        except Exception as e:
            self.root.after(0, lambda: self._load_model_fail(e))

    def _load_model_success(self, model, sp, info):
        self.model = model
        self.sp = sp
        self.ckpt_info = info
        self.is_loading = False
        self._set_ui_busy(False)
        self.model_info_label.configure(
            text=f"모델: {Path(info['ckpt_path']).name} / iter={info['iter_num']} / loss={info['best_val_loss']}"
        )
        self._set_status(f"로드 완료 | {Path(info['ckpt_path']).name}")
        self._append_message("system", f"체크포인트 로드 완료: {Path(info['ckpt_path']).name}")

    def _load_model_fail(self, error):
        self.model = None
        self.sp = None
        self.ckpt_info = None
        self.is_loading = False
        self._set_ui_busy(False)
        self.model_info_label.configure(text="모델: 로드 실패")
        self._set_status("모델 로드 실패")
        self._append_message("error", str(error))
        messagebox.showerror("모델 로드 실패", str(error))

    def send_message(self):
        if self.is_loading:
            self._append_message("system", "아직 모델을 불러오는 중이다.")
            return
        if self.is_generating:
            return

        user_text = self.entry.get().strip()
        if not user_text:
            return

        self.entry.delete(0, tk.END)
        self._append_message("user", user_text)

        if looks_like_math_expression(user_text):
            self._handle_math(user_text)
            return

        if self.model is None or self.sp is None:
            self._append_message("error", "모델이 로드되지 않았다.")
            return

        self.is_generating = True
        self._set_ui_busy(True)
        self._set_status("응답 생성 중...")

        thread = threading.Thread(target=self._generate_reply_worker, args=(user_text,), daemon=True)
        thread.start()

    def _handle_math(self, expr: str):
        try:
            result = safe_eval_math(expr)
            self._append_message("calc", f"결과: {result}")
            self._set_status("계산 완료")
        except Exception as e:
            self._append_message("error", f"수학식 계산 실패: {e}")
            self._set_status("계산 실패")

    def _generate_reply_worker(self, user_text: str):
        try:
            prompt = f"[대화 시작]\n화자1: {user_text}\n화자2:"
            result = generate_text(
                model=self.model,
                sp=self.sp,
                prompt=prompt,
                max_new_tokens=MAX_NEW_TOKENS,
                temperature=TEMPERATURE,
                top_k=TOP_K,
            )

            answer = result
            if "화자2:" in answer:
                answer = answer.split("화자2:", 1)[-1].strip()
            if "화자1:" in answer:
                answer = answer.split("화자1:", 1)[0].strip()
            if not answer.strip():
                answer = "응답을 생성하지 못했다."

            self.root.after(0, lambda: self._generate_reply_success(answer))
        except Exception as e:
            self.root.after(0, lambda: self._generate_reply_fail(e))

    def _generate_reply_success(self, answer: str):
        self.is_generating = False
        self._set_ui_busy(False)
        self._set_status("대기 중")
        self._append_message("bot", answer)

    def _generate_reply_fail(self, error):
        self.is_generating = False
        self._set_ui_busy(False)
        self._set_status("응답 생성 실패")
        self._append_message("error", str(error))


def main():
    root = tk.Tk()
    app = ChatChosimApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()